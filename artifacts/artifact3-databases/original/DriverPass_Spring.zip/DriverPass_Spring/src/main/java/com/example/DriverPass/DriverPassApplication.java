package com.example.DriverPass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverPassApplication {
	public static void main(String[] args) {
		SpringApplication.run(DriverPassApplication.class, args);
	}
}